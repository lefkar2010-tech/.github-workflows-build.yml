package com.example.gmtools

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

class Radial(c: Context, val pick: (Int) -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val names = arrayOf("Репорт", "Админ меню")

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val m = w / 2
        val r = RectF(4f, 4f, w - 4, w - 4)
        p.style = Paint.Style.FILL
        for (i in 0 until 4) {
            p.color = if (i < 2) 0xFF6A3FD4.toInt() else 0x66303050
            cv.drawArc(r, -90f + i * 90f + 1.5f, 87f, true, p)
        }
        p.color = 0xFF14162B.toInt()
        cv.drawCircle(m, m, w * 0.2f, p)
        p.color = -1
        p.textSize = w * 0.07f
        p.textAlign = Paint.Align.CENTER
        p.isFakeBoldText = true
        for (i in 0 until 2) {
            val a = Math.toRadians((-45 + i * 90).toDouble())
            cv.drawText(names[i], m + (Math.cos(a) * w * 0.33).toFloat(), m + (Math.sin(a) * w * 0.33).toFloat() + p.textSize / 3, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val m = width / 2f
            val dx = e.x - m
            val dy = e.y - m
            val r = width * 0.2f
            if (dx * dx + dy * dy > r * r && dx > 0) pick(if (dy < 0) 0 else 1)
        }
        return true
    }
}
