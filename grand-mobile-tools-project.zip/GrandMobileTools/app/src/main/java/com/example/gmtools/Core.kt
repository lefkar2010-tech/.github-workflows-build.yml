package com.example.gmtools

import android.content.Context
import org.json.JSONArray

class Report(val time: String, val nick: String, val id: String, val text: String, val queue: String) {
    val key: String get() = time + "|" + id + "|" + text
}

object Core {
    val reports = ArrayList<Report>()
    val logs = ArrayList<String>()
    val closed = HashSet<String>()
    var onChange: (() -> Unit)? = null
    private val seen = HashMap<String, Long>()

    private val rep = Regex("""(?:(\d{1,2}:\d{2}(?::\d{2})?)\]?\s+)?([A-Za-z0-9_А-Яа-я.\-]+)[\[(](\d{1,5})[\])]:?\s*(.*?)\s*\[К-?во репорта:?\s*(\d+)\s*\]""", RegexOption.IGNORE_CASE)
    private val line = Regex("""^\W{0,3}(?:\d{1,2}:\d{2}(?::\d{2})?\W{0,3}\s*)?(?:<ADM>|[A-Za-z0-9_А-Яа-я.\-]+[\[(]\d{1,5}[\])])""")
    private val ans = Regex("""(\S+)[\[(]\d{1,5}[\])]:?\s+ответил\s+\S+[\[(](\d{1,5})[\])]""", RegexOption.IGNORE_CASE)

    fun feed(lines: List<String>, quiet: Boolean) {
        val now = System.currentTimeMillis()
        var ch = false
        for (l in lines) {
            if (!line.containsMatchIn(l)) continue
            val p = seen[l]
            seen[l] = now
            if (quiet || (p != null && now - p < 30000)) continue
            logs.add(l)
            if (logs.size > 3000) logs.removeAt(0)
            ch = true
            val m = rep.find(l)
            if (m != null) {
                val r = Report(m.groupValues[1], m.groupValues[2], m.groupValues[3], m.groupValues[4], m.groupValues[5])
                if (r.key !in closed && reports.none { it.key == r.key }) reports.add(r)
            }
            val a = ans.find(l)
            if (a != null && !a.groupValues[1].equals("Grnd_Bot", true)) reports.removeAll { it.id == a.groupValues[2] }
        }
        if (seen.size > 600) seen.entries.removeAll { now - it.value > 600000 }
        if (ch) onChange?.invoke()
    }

    fun list(c: Context, k: String, def: List<List<String>>): MutableList<MutableList<String>> {
        val s = c.getSharedPreferences("gmt", 0).getString(k, null)
        if (s == null) return def.map { it.toMutableList() }.toMutableList()
        val a = JSONArray(s)
        val out = ArrayList<MutableList<String>>()
        for (i in 0 until a.length()) {
            val r = a.getJSONArray(i)
            out.add((0 until r.length()).map { r.getString(it) }.toMutableList())
        }
        return out
    }

    fun save(c: Context, k: String, v: List<List<String>>) {
        c.getSharedPreferences("gmt", 0).edit().putString(k, JSONArray(v.map { JSONArray(it) }).toString()).apply()
    }

    fun nav(c: Context): List<Pair<String, List<String>>> {
        val out = ArrayList<Pair<String, MutableList<String>>>()
        val re = Regex("""^(\d+)(\.\d+)?\.\s+(.+)$""")
        for (l in c.assets.open("navigator.cfg").bufferedReader().readLines()) {
            val m = re.find(l.trim()) ?: continue
            if (m.groupValues[2].isEmpty()) out.add(Pair(m.groupValues[3], ArrayList<String>())) else out.lastOrNull()?.second?.add(m.groupValues[3])
        }
        return out
    }

    val ANS = listOf(
        listOf("не пред услугу", "не предоставляем данную услугу"),
        listOf("не тп", "не телепортируем"),
        listOf("рп процесс", "не вмешиваемся в РП процесс"),
        listOf("узнайте у игроков", "данную информацию можете узнать у игроков"),
        listOf("не владеем инф", "не владеем данной информацией"),
        listOf("мп", "телепорт на мероприятие закрыт"),
        listOf("не согл с наказ", "не согласны с наказанием? Напишите жалобу"),
        listOf("док-ва", "если есть доказательства - напишите жалобу"),
        listOf("приятной игры", "приятной игры на Grand Mobile"),
        listOf("озн с правилами", "ознакомьтесь с правилами в лаунчере игры")
    )

    val RULES = listOf(
        listOf("mu", "mute", "20 2.7 ОП"), listOf("osk", "mute", "30 2.1 ОП"), listOf("fl", "mute", "20 2.2 ОП"),
        listOf("rod", "ban", "7 2.1 ОП"), listOf("qwe", "ban", "31 5.2 ОП"), listOf("zxc", "ban", "31 снят/адм"),
        listOf("adm", "ban", "3 3.2 ОП"), listOf("dm", "jail", "60 DM"), listOf("db", "jail", "40 DB"),
        listOf("ub", "jail", "30 UB"), listOf("gz", "jail", "120 1.1 GZ"), listOf("gzz", "warn", "1.1 GZ"),
        listOf("sk", "jail", "60 SK"), listOf("skk", "warn", "SK"), listOf("opg", "warn", "2.2 ОПГ"),
        listOf("dom", "jail", "60 5.7 ОП"), listOf("domm", "warn", "5.7 ОП"), listOf("tk", "jail", "60 TK"), listOf("tkk", "warn", "TK")
    )

    val PUN = listOf(
        listOf("MUTE", "/mute {id} {time} {reason}"), listOf("JAIL", "/jail {id} {time} {reason}"),
        listOf("KICK", "/kick {id} {reason}"), listOf("BAN", "/ban {id} {time} {reason}"),
        listOf("WARN", "/warn {id} {reason}"), listOf("SKICK", "/skick {id} {reason}")
    )
}
