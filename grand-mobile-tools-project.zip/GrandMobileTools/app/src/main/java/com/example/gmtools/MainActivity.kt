package com.example.gmtools

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(48, 80, 48, 48)
        val t = TextView(this)
        t.textSize = 16f
        t.text = "Grand Mobile Tools\n\n1. Нажми кнопку ниже и включи службу «Grand Mobile Tools».\n2. Открой игру: появится кружок GM.\n\nЕсли переключатель недоступен: Настройки → Приложения → Grand Mobile Tools → ⋮ → «Разрешить ограниченные настройки»."
        val bt = Button(this)
        bt.text = "Открыть специальные возможности"
        bt.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        l.addView(t)
        l.addView(bt)
        setContentView(l)
    }
}
