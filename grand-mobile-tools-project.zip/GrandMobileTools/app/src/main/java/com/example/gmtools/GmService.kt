package com.example.gmtools

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class GmService : AccessibilityService() {
    private val hd = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var bubbleP: WindowManager.LayoutParams
    private val wins = HashMap<String, View>()
    private var bubble: View? = null
    private var radial: View? = null
    private var base = ""
    private var pend = false
    private var edit: AccessibilityNodeInfo? = null
    private var lastSet = ""
    private val expandTask = Runnable { expand() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Core.onChange = { if (wins.containsKey("rep")) openReports() }
        showBubble()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        wins.keys.toList().forEach { close(it) }
        radial?.let { wm.removeView(it) }
        bubble?.let { wm.removeView(it) }
        Core.onChange = null
        super.onDestroy()
    }

    // ---------- чтение чата и отправка ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.packageName?.toString() == packageName) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            val s = e.source
            if (s != null && s.isEditable) {
                edit = s
                hd.removeCallbacks(expandTask)
                hd.postDelayed(expandTask, 600)
            }
        }
        if (!pend) {
            pend = true
            hd.postDelayed({ pend = false; scan() }, 300)
        }
    }

    private fun gameRoot(): AccessibilityNodeInfo? {
        for (w in windows) {
            val r = w.root ?: continue
            if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION && r.packageName?.toString() != packageName) return r
        }
        val a = rootInActiveWindow
        return if (a != null && a.packageName?.toString() != packageName) a else null
    }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<String>, cnt: IntArray) {
        if (n == null || cnt[0]++ > 4000) return
        n.text?.let { out.add(it.toString()) }
        n.contentDescription?.let { out.add(it.toString()) }
        for (i in 0 until n.childCount) walk(n.getChild(i), out, cnt)
    }

    private fun scan() {
        val root = gameRoot() ?: return
        val pkg = root.packageName?.toString() ?: return
        val raw = ArrayList<String>()
        walk(root, raw, IntArray(1))
        val lines = raw.flatMap { it.split('\n') }.map { it.trim() }.filter { it.isNotEmpty() }
        val quiet = pkg != base
        base = pkg
        Core.feed(lines, quiet)
    }

    private fun editable(n: AccessibilityNodeInfo?, o: ArrayList<AccessibilityNodeInfo>): ArrayList<AccessibilityNodeInfo> {
        if (n == null) return o
        if (n.isEditable && n.isEnabled) o.add(n)
        for (i in 0 until n.childCount) editable(n.getChild(i), o)
        return o
    }

    private fun sendOne(c: String, tries: Int) {
        val l = editable(gameRoot(), ArrayList())
        val n = l.firstOrNull { it.isFocused } ?: l.firstOrNull()
        if (n == null) {
            if (tries > 0) hd.postDelayed({ sendOne(c, tries - 1) }, 500) else toast("Откройте поле ввода чата в игре")
            return
        }
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, c + "\n")
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun send(vararg cs: String) {
        cs.forEachIndexed { i, c -> hd.postDelayed({ sendOne(c, 4) }, 1000L * i + 150) }
    }

    private fun expand() {
        val n = edit ?: return
        if (!n.refresh()) return
        val cur = n.text?.toString() ?: return
        if (cur == lastSet || !cur.startsWith("/")) return
        val sp = cur.indexOf(' ')
        if (sp < 0) return
        val cmd = cur.substring(1, sp).lowercase()
        val m = Regex("""^(\d+)$""").find(cur.substring(sp + 1).trim()) ?: return
        val r = Core.list(this, "rules", Core.RULES).firstOrNull { it[0].lowercase() == cmd } ?: return
        val out = "/" + r[1] + " " + m.groupValues[1] + (if (r.size > 2 && r[2].isNotEmpty()) " " + r[2] else "")
        val a = Bundle()
        a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, out)
        if (!n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)) return
        lastSet = out
        val s = Bundle()
        s.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, out.length)
        s.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, out.length)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, s)
    }

    // ---------- окна и элементы ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun bg(c: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(c)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun tv(t: String, s: Float = 14f, b: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = s
        v.setTextColor(-1)
        if (b) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(dp(8), dp(6), dp(8), dp(6))
        return v
    }

    private fun btn(t: String, c: Int = 0xFF5B3FD4.toInt(), f: () -> Unit): TextView {
        val v = tv(t, 14f, true)
        v.gravity = Gravity.CENTER
        v.background = bg(c, 10)
        v.setOnClickListener { f() }
        return v
    }

    private fun add(g: LinearLayout, v: View, wt: Float = -1f): LinearLayout {
        val h = g.orientation == LinearLayout.HORIZONTAL
        val w = if (wt < 0) (if (h) 1f else 0f) else wt
        val p = LinearLayout.LayoutParams(if (h) 0 else -1, -2, w)
        p.setMargins(dp(3), dp(3), dp(3), dp(3))
        g.addView(v, p)
        return g
    }

    private fun col(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        v.forEach { add(l, it) }
        return l
    }

    private fun row(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        v.forEach { add(l, it) }
        return l
    }

    private fun grid(cols: Int, v: List<View>): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        v.chunked(cols).forEach { ch -> add(l, row(*ch.toTypedArray())) }
        return l
    }

    private fun et(h: String): EditText {
        val e = EditText(this)
        e.hint = h
        e.setTextColor(-1)
        e.setHintTextColor(0xFF8888AA.toInt())
        e.setSingleLine()
        e.background = bg(0xFF262945.toInt(), 8)
        e.setOnTouchListener { v, _ ->
            wins.entries.firstOrNull { it.value === v.rootView }?.let { focus(it.key, true) }
            false
        }
        return e
    }

    private fun lp(w: Int, h: Int, g: Int, x: Int, y: Int): WindowManager.LayoutParams {
        val p = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        p.gravity = g
        p.x = x
        p.y = y
        return p
    }

    private fun open(key: String, v: View, w: Int, h: Int) {
        close(key)
        val p = lp(w, h, Gravity.CENTER, 0, 0)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wins[key] = v
        wm.addView(v, p)
    }

    private fun close(key: String) {
        val v = wins.remove(key) ?: return
        try { wm.removeView(v) } catch (e: Exception) {}
    }

    private fun focus(key: String, on: Boolean) {
        val v = wins[key] ?: return
        val p = v.layoutParams as WindowManager.LayoutParams
        p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv() else p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(v, p)
    }

    private fun panel(key: String, title: String, body: View, w: Int, tall: Boolean) {
        val box = col()
        box.background = bg(0xF2181A2E.toInt(), 16)
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        val bar = row()
        add(bar, tv(title, 16f, true), 5f)
        add(bar, btn("✕", 0xFF8B2C3C.toInt()) { close(key) }, 1f)
        add(box, bar)
        val sv = ScrollView(this)
        sv.addView(body)
        add(box, sv, if (tall) 1f else 0f)
        open(key, box, dp(w), if (tall) minOf(dp(540), (resources.displayMetrics.heightPixels * 0.85).toInt()) else -2)
    }

    // ---------- кружок и круговое меню ----------
    private fun showBubble() {
        val b = tv("GM", 13f, true)
        b.gravity = Gravity.CENTER
        b.background = bg(0xFF5B3FD4.toInt(), 22)
        val p = lp(dp(44), dp(44), Gravity.TOP or Gravity.START, dp(8), dp(160))
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) {
                        p.x = sx + (e.rawX - dx).toInt()
                        p.y = sy + (e.rawY - dy).toInt()
                        wm.updateViewLayout(b, p)
                        if (radial != null) toggleRadial()
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) toggleRadial()
            }
            true
        }
        bubble = b
        bubbleP = p
        wm.addView(b, p)
    }

    private fun toggleRadial() {
        val old = radial
        if (old != null) {
            wm.removeView(old)
            radial = null
            return
        }
        val s = dp(240)
        val bp = bubbleP
        val v = Radial(this) { i -> hd.post { toggleRadial(); if (i == 0) openReports() else openAdmin() } }
        wm.addView(v, lp(s, s, Gravity.TOP or Gravity.START, bp.x + dp(22) - s / 2, bp.y + dp(22) - s / 2))
        radial = v
        hd.post {
            val b = bubble
            if (b != null) {
                wm.removeView(b)
                wm.addView(b, bp)
            }
        }
    }

    // ---------- репорты и окно жалобы ----------
    private fun openReports() {
        val b = col()
        if (Core.reports.isEmpty()) add(b, tv("Новых репортов нет"))
        for (r in Core.reports.toList()) {
            val rw = row()
            add(rw, tv(r.time + "  " + r.nick + "[" + r.id + "]\n" + r.text + " · очередь " + r.queue, 13f), 4f)
            add(rw, btn("✓", 0xFF8B2C3C.toInt()) { Core.closed.add(r.key); Core.reports.remove(r); close("rep"); openComplaint(r) }, 1f)
            add(b, rw)
        }
        panel("rep", "Репорты (" + Core.reports.size + ")", b, 340, false)
    }

    private fun answer(r: Report, t: String) {
        send("/ans " + r.id + " " + t)
        close("cmp"); close("qa"); close("nav")
    }

    private fun openComplaint(r: Report) {
        val inp = et("Введите свой ответ")
        val b = col(tv("Жалоба/Вопрос от: " + r.nick + "[" + r.id + "]", 15f, true), tv(r.text, 15f))
        val rw = row()
        add(rw, inp, 3f)
        add(rw, btn("Ответить") { if (inp.text.isNotBlank()) answer(r, inp.text.toString().trim()) }, 1.4f)
        add(b, rw)
        add(b, grid(2, listOf(
            btn("Уточните") { answer(r, "Приветствую, уточните ваш вопрос/жалобу.") },
            btn("Оффтоп") { answer(r, "Приветствую, при последующем оффтопе вы будете наказаны.") },
            btn("Другие наказания") { openPunish(r.id) },
            btn("GPS Навигатор") { openNav(r) },
            btn("Быстрые ответы") { openQuick(r) },
            btn("Помощь в пути") {
                send("/ans " + r.id + " Приветствую, сейчас попробую вам помочь.", "/sp " + r.id)
                close("cmp")
                openPunish(r.id)
            },
            btn("Спросить в /a") { send("/a " + r.nick + "[" + r.id + "]: " + r.text); close("cmp") }
        )))
        panel("cmp", "Жалоба/Вопрос от игрока", b, 360, false)
    }

    private fun openQuick(r: Report) {
        val b = col()
        for (a in Core.list(this, "ans", Core.ANS)) add(b, btn(a[0], 0xFF2A2D4A.toInt()) { answer(r, a[1]) })
        panel("qa", "Быстрые ответы", b, 340, true)
    }

    private fun openNav(r: Report) {
        val b = col()
        for ((cat, items) in Core.nav(this)) {
            if (items.isEmpty()) {
                add(b, btn(cat, 0xFF2A2D4A.toInt()) { answer(r, "GPS → " + cat) })
            } else {
                add(b, tv(cat, 14f, true))
                for (s in items) add(b, btn(s, 0xFF2A2D4A.toInt()) { answer(r, "GPS → " + cat + " → " + s) })
            }
        }
        panel("nav", "GPS Навигатор", b, 340, true)
    }

    // ---------- наказания ----------
    private fun openPunish(id: String) {
        val b = col()
        for (p in Core.PUN) add(b, btn(p[0]) { openPun(p[0], p[1], id) })
        panel("pun", "Наказание ID " + id, b, 190, false)
    }

    private fun openPun(name: String, tpl: String, id: String) {
        var reason = ""
        var time = ""
        val hasTime = tpl.contains("{time}")
        val rs = listOf("ДМ", "ДБ", "ДМ ЗЗ", "ган ЗЗ", "ТК", "СК", "опру", "nonRP")
        val ts = listOf("20", "30", "60", "120", "180", "300", "1000", "3000")
        val rc = col()
        val tc = col()
        fun mark(c: LinearLayout, sel: Int) {
            for (i in 0 until c.childCount) c.getChildAt(i).background = bg(if (i == sel) 0xFF5B3FD4.toInt() else 0xFF2A2D4A.toInt(), 8)
        }
        rs.forEachIndexed { i, s -> add(rc, btn(s, 0xFF2A2D4A.toInt()) { reason = s; mark(rc, i) }) }
        if (hasTime) ts.forEachIndexed { i, s -> add(tc, btn(s + " мин.", 0xFF2A2D4A.toInt()) { time = s; mark(tc, i) }) }
        val cr = et("Другая причина")
        val cm = et("Минуты")
        val ok = btn("Подтвердить") {
            val r = (if (cr.text.isNotBlank()) cr.text.toString() else reason).trim().lowercase()
            val t = (if (cm.text.isNotBlank()) cm.text.toString() else time).trim()
            if (r.isEmpty() || (hasTime && t.isEmpty())) {
                toast("Выберите причину" + (if (hasTime) " и время" else ""))
            } else {
                send(tpl.replace("{id}", id).replace("{time}", t).replace("{reason}", r))
                close("pd")
            }
        }
        val b = col(tv(name + "  ID " + id, 17f, true))
        add(b, if (hasTime) row(rc, tc) else row(rc))
        add(b, if (hasTime) row(cr, cm) else row(cr))
        add(b, row(ok, btn("Отмена", 0xFF8B2C3C.toInt()) { close("pd") }))
        panel("pd", "Быстрые наказания", b, 340, true)
    }

    // ---------- админ меню ----------
    private fun openAdmin() {
        val content = col()
        val side = col(btn("Редактор") { editor(content) }, btn("Логи") { logs(content) })
        val b = row()
        add(b, side, 1f)
        add(b, content, 2.4f)
        editor(content)
        panel("adm", "Админ меню", b, 360, true)
    }

    private fun editor(c: LinearLayout) {
        c.removeAllViews()
        add(c, tv("Редактор", 16f, true))
        add(c, btn("Быстрые ответы") { listEd(c, "ans", Core.ANS, listOf("Название", "Ответ")) { it[0] + " → " + it[1] } })
        add(c, btn("Быстрые наказания") { listEd(c, "rules", Core.RULES, listOf("Сокращение (mu)", "Команда (mute)", "Аргументы (20 2.7 ОП)")) { "/" + it[0] + " → /" + it[1] + " {id} " + (if (it.size > 2) it[2] else "") } })
    }

    private fun listEd(c: LinearLayout, key: String, def: List<List<String>>, hints: List<String>, fmt: (List<String>) -> String) {
        c.removeAllViews()
        add(c, btn("← Редактор", 0xFF2A2D4A.toInt()) { editor(c) })
        val data = Core.list(this, key, def)
        data.forEachIndexed { i, r ->
            val rw = row()
            add(rw, tv(fmt(r), 12f), 3f)
            add(rw, btn("Удалить", 0xFF3A55C8.toInt()) { data.removeAt(i); Core.save(this, key, data); listEd(c, key, def, hints, fmt) }, 1.3f)
            add(c, rw)
        }
        val f = hints.map { et(it) }
        f.forEach { add(c, it) }
        add(c, btn("Добавить") {
            val v = f.map { it.text.toString().trim() }
            if (v.take(2).all { it.isNotEmpty() }) {
                data.add(v.toMutableList())
                Core.save(this, key, data)
                listEd(c, key, def, hints, fmt)
            }
        })
    }

    private fun logs(c: LinearLayout) {
        c.removeAllViews()
        add(c, tv("Логи", 16f, true))
        val q = et("Поиск по чату")
        val out = col()
        fun upd() {
            out.removeAllViews()
            val s = q.text.toString().trim()
            val m = Core.logs.filter { s.isEmpty() || it.contains(s, true) }.takeLast(60).reversed()
            if (m.isEmpty()) add(out, tv("Ничего нет"))
            for (l in m) add(out, tv(l, 12f))
        }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { upd() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
        })
        add(c, q)
        add(c, out)
        upd()
    }
}
